import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
public class MCQ {                                                              //to declares a member's access as public
    public static void main(String[] args) throws FileNotFoundException {
        System.out.println("Good Day! Have a Nice Test.");
        System.out.println("Enter your name: ");
        Scanner sc = new Scanner(System.in);
        String name = sc.nextLine();
        int score=0;
        int wrong=0;
        System.out.println("Choose your Multiple Choice Question Set. The Options are :");
        System.out.println("1. HTML Basics");
        System.out.println("2. CSS Basics");
        System.out.println("3. Java Basics");
        int choice = sc.nextInt();
        if (choice == 1) {
            System.out.println("HTML basics questions");
            File f = new File("MCQ1.csv");
            Scanner q1 = new Scanner(f);                                    //to read the CSV File
            while (q1.hasNextLine()) {
                String line = q1.nextLine();
                String line_array[] = new String[6];
                line_array = line.split(",");
                System.out.println(line_array[0]);
                System.out.println(line_array[1]);                         //answer choices
                System.out.println("A.)" + line_array[2]);
                System.out.println("B.)" + line_array[3]);
                System.out.println("C.)" + line_array[4]);
                System.out.println("D.)" + line_array[5]);
                System.out.println();
                Scanner ques = new Scanner(System.in);                     //to read questions
                System.out.print("Enter your Answer: ");
                String correctAnswer = ques.nextLine();

                if (correctAnswer.equalsIgnoreCase(line_array[6])) {
                    score++;
                    System.out.println("** Your Answer is Correct \uD83D\uDE0A **");

                } else {
                    System.out.println("Incorrect. \uD83E\uDD7A " + "The correct Answer is: " + line_array[6]);

                }

            }
        } else if (choice == 2) {
            System.out.println("CSS basics questions");
            File g = new File("MCQ2.csv");
            Scanner q1 = new Scanner(g);
            while (q1.hasNextLine()) {
                String line = q1.nextLine();
                String line_array[] = new String[6];
                line_array = line.split(",");
                System.out.println(line_array[0]);
                System.out.println(line_array[1]);
                System.out.println("A.)" + line_array[2]);
                System.out.println("B.)" + line_array[3]);
                System.out.println("C.)" + line_array[4]);
                System.out.println("D.)" + line_array[5]);
                System.out.println();
                Scanner ques = new Scanner(System.in);
                System.out.print("Enter your Answer: ");
                String correctAnswer = ques.nextLine();

                if (correctAnswer.equalsIgnoreCase(line_array[6])) {
                    System.out.println("** Your Answer is Correct \uD83D\uDE0A **");
                score++;
                } else {
                    System.out.println("Incorrect. \uD83E\uDD7A " + "The correct Answer is: " + line_array[6]);
                    wrong++;
                }


            }
        } else if (choice == 3) {

            System.out.println("JAVA basics questions");
            File h = new File("MCQ3.csv");
            Scanner v1 = new Scanner(h);
            while (v1.hasNextLine()) {
                String line = v1.nextLine();
                String line_array[] = new String[6];
                line_array = line.split(",");
                System.out.println(line_array[0]);
                System.out.println(line_array[1]);
                System.out.println("A.)" + line_array[2]);
                System.out.println("B.)" + line_array[3]);
                System.out.println("C.)" + line_array[4]);
                System.out.println("D.)" + line_array[5]);
                System.out.println();
                Scanner ques = new Scanner(System.in);
                System.out.print("Enter your Answer: ");
                String correctAnswer = ques.nextLine();

                if (correctAnswer.equalsIgnoreCase(line_array[6])) {
                    System.out.println("** Your Answer is Correct \uD83D\uDE0A **");
                score++;
                } else {
                    System.out.println("Incorrect. \uD83E\uDD7A " + "The correct Answer is: " + line_array[6]);
                wrong++;
                }

            }
        }

                System.out.println();
                if (score >=8 && score <=10){
                    System.out.println("Congratulations You Passed!");
                }else {
                    System.out.println("Sorry You Failed\nOww no!! Please Retake The MCQ!! ");
                }
                System.out.println(name+" Your score is "+(score)+"/10");
                System.out.println("Your average is " +(score *10)+"%");
                System.out.println();
                System.out.println("You're Incorrect is "+wrong);
    }
}
